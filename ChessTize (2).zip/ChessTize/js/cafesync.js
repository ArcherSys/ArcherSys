var TogetherJSConfig_toolName = "CafeSync";
TogetherJSConfig_inviteFromRoom = true;
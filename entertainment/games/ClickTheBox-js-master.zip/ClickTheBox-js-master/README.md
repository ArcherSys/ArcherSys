# Click The Box

Simple app for the Dropbox Datastore API that demos game state. You can play the game at [clickthebox.site44.com](https://clickthebox.site44.com).

Read more about it on [the Dropbox Developers Blog](https://www.dropbox.com/developers/blog/83/click-the-box-a-cross-platform-open-source-game-using-the-datastore-api).

![Screenshot](screenshot.png)

### All versions

* [JavaScript](https://github.com/dropbox/ClickTheBox-js)
* [iOS](https://github.com/dropbox/ClickTheBox-ios)
* [Android](https://github.com/dropbox/ClickTheBox-android)

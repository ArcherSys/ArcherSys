var Mandalore = Mandalore || {};
Mandalore.Territory = function(name,house){
   this.name = name;
   this.house = house;
};
var gamejs = require('gamejs');
require('./y8y2/preloader').preload();

gamejs.ready(function() {
});

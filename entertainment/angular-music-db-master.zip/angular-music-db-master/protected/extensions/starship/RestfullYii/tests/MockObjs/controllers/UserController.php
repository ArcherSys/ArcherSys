<?php
class UserController extends ERestBaseTestController
{
	//Mock Test Controller
}


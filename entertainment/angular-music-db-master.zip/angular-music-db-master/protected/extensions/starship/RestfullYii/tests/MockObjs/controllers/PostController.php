<?php
class PostController extends ERestBaseTestController
{
	//Mock Test Controller
}


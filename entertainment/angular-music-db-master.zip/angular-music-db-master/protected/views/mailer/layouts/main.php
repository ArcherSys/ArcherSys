<!doctype html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title><?php echo Yii::app() ->name;?></title>
	</head>
    <body  style="background-image: url('https://public.dm1.livefilestore.com/y1pbbw8oJ8RN7TLtKbMsBEXPQXeSYw-A9SJxmP-aIbu0KpPaGgM6elsq841J1Zyt6A1eoGdeGCaEmX3PcYl0bAlYg/POloi.jpg?psid=1'); background-color:#00008b;
    color:white " leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
    	<center style="height:500px;">
            <img src="https://wpsjcw.dm1.livefilestore.com/y1pZM4o9V-C98n2JdDmgoD5Ap_YAy2Og3iAc8VD2TvCcjakLzsnanuPOuHt22RInwhPI2pFT77MM5Ve0u-gw6gFVovBNZDLrriT/yii-bwh.png?psid=1" style="width:600px" />
            <h1 style="font-size: 40px; color:#a1dfdc" class="h1"><?php echo Yii::app() ->name;?></h1>
            <div style="margin-top: 250px;">
            <?php echo $content; ?>
            </div>
            <div style="margin-top: 40px;">
            <em >Copyright &copy; 2013  <?php echo Yii::app() ->name;?> , All rights reserved.</em>
            </div>
        </center>
    </body>
</html>
<center>
    <h1 style="font-size: 30px; margin-left: auto;  margin-right: auto;width:600px;"> <?php echo $subject;?></h1>
   <h2 style="font-size: 20px; margin-left: auto;  margin-right: auto;width:600px;"> <?php echo $name;?> (<?php echo $email;?> )</h2>
    <p style="font-size: 15px; margin-left: auto;  margin-right: auto;width:600px;">
        <?php echo $body;?>
    </p>
</center>

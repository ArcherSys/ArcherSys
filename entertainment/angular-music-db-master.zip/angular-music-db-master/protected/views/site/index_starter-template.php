<div class="starter-template">
    <h1>Bootstrap starter template</h1>

    <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a
        mostly barebones HTML document.</p>

    <h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

    <p>You may change the content of this page by modifying the following two files:</p>
    <ul>
        <li>Views file: <?php echo __FILE__; ?></li>
        <li>Layout file: <?php echo $this->getLayoutFile('starter'); ?></li>
    </ul>
    <p>For more details on how to further develop this application, please read
        the <a href="http://www.yiiframework.com/doc/">documentation</a>.
        Feel free to ask in the <a href="http://www.yiiframework.com/forum/">forum</a>
</div>
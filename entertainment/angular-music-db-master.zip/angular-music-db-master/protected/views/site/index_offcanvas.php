<div class="jumbotron">
    <h1>Hello, world!</h1>

    <p>This is an example to show the potential of an offcanvas layout pattern in Bootstrap. Try some responsive-range
        viewport sizes to see it in action.</p>
</div>
<div class="row">
    <div class="col-12 col-sm-12 col-lg-12 ">
        <h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

        <p>You may change the content of this page by modifying the following two files:</p>
        <ul>
            <li>Views file: <?php echo __FILE__; ?></li>
            <li>Layout file: <?php echo $this->getLayoutFile('offcanvas'); ?></li>
    </div>
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
    <div class="col-6 col-sm-6 col-lg-4">
        <h2>Heading</h2>

        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris
            condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod.
            Donec sed odio dui. </p>

        <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
    </div>
    <!--/span-->
</div><!--/row-->
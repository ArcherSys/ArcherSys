/**
 *  File bootstrap.js  in Project Music Database
 *  Date: October 12 th 2013 , 3:42 PM
 *  Author Spiros Kabasakalis , kabasakalis@gmail.com
 *  Github https://github.com/drumaddict
 * InfoWebSphere,http://iws.kabasakalis.gr
 * YiiLab,http://yiilab.kabasakalis.tk
 */


window.music_db.App.defineModules();
window.music_db.App.config();
window.music_db.App.restangularConfig();
window.music_db.App.run();
window.music_db.App.start();


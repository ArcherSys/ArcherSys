<div class="pulldown  page-min-height" >
<?php
$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>

<h1 class="page-header">About</h1>

<p>This is a "static" page. You may change the content of this page
by updating the file  <?php echo __FILE__; ?>.</p>

</div>
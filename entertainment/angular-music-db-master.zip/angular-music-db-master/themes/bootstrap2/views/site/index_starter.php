<?php $this->pageTitle = Yii::app()->name; ?>
    <h1 class="page-header">Welcome to  <?php echo CHtml::encode(Yii::app()->name); ?></h1>
    <h3>Bootstrap starter template</h3>
    <p>Use this document as a way to quick start any new project.<br> All you get is this message and a barebones HTML document.</p>
    <p>You may change the content of this page by modifying the following two files:</p>
    <ol>
        <li>Views file: <?php echo __FILE__; ?></li>
        <li>Layout file: <?php echo $this->getLayoutFile('starter'); ?></li>
    </ol>
    <p>For more details on how to further develop this application, please read
        the <a href="http://www.yiiframework.com/doc/">documentation</a>.
        Feel free to ask in the <a href="http://www.yiiframework.com/forum/">forum</a>



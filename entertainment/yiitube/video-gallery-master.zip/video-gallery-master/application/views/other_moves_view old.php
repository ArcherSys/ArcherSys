<?php
$data = array();
include('other_moves_builder_view.php');
echo json_encode($data);
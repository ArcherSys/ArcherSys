<?php
include('batch_builder_view.php');
//$data['session'] = $session;
//if (isset($clearing)) $data['clearing'] = $clearing; 
echo json_encode($data);
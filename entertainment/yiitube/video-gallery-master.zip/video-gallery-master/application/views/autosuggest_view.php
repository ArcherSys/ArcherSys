<?php
/**
 * Return search autosuggest text.
 * 
 * @package    VideoGallery
 * @copyright  Copyright (c) 2011 Andrew Weeks http://meloncholy.com
 * @license    MIT licence. See licence.txt for details.
 * @version    0.1
 */

$data['autosuggest'] = $autosuggest;
echo json_encode($data);
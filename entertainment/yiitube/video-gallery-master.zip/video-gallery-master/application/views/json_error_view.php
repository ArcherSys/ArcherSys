<?php
$data['error'] = $error;
echo json_encode($data);

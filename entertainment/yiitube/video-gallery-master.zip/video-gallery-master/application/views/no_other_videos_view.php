<?php
// NOT USED?
$data['prevVideos'] = '';
$data['nextVideos'] = '';
echo json_encode($data);
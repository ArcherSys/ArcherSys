<?php

// NOT USED

class Filters
{
	public $difficulty;
	public $strength;
	public $flexibility;
	public $invert;
	public $spin;
	public $has_filters = false;
}
time ./ffmpeg_native -i big_buck_bunny.webm -vf showinfo,scale=w=-1:h=-1 -strict experimental -v verbose output.mov

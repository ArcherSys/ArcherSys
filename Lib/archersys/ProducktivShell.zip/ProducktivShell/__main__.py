import Lib.archersys.ProducktivShell.core as core

   
contacts = core.ProducktivShellRolodex()
contacts.cmdloop()
         

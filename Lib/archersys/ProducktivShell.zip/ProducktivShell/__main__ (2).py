from Lib.archersys.ProducktivShell import core
contacts = core.ProducktivShellRolodex()
contacts.cmdloop()
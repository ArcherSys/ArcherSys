
var Mapsly = {};
Mapsly.MapStats = function(lat,lng,zoom){
this.center = new Mapsly.GeoPoint(lat,lng);
this.zoom = zoom;
};
Mapsly.MarkerSettings = function(map,position,title){
    this.map = map;
    this.position = position;
    this.title = title;
};
Mapsly.GeoPoint = function(lat,lng){
    this.lat = lat;
    this.lng = lng;
};

Blockly.Blocks['document_gebid'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Get Element By ID");
    this.setOutput(true, "HTMLDivElement");
    this.setColour(65);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['document_gebid'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = 'window.document.getElementById("map")';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};
Blockly.Blocks['mapsly_geopoint'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("new GeoPoint");
    this.appendValueInput("LAT")
        .setCheck("Number")
        .appendField("Latitude:");
    this.appendValueInput("LNG")
        .setCheck("Number")
        .appendField("Longitude:");
    this.setOutput(true, "Mapsly.GeoPoint");
    this.setColour(160);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.Blocks['marker_addlistener'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Add Event Handler for Marker");
    this.appendValueInput("Marker")
        .setCheck("google.maps.Marker")
        .appendField("Marker");
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([["click", "click"]]), "EventType");
    this.appendStatementInput("code")
        .appendField("Code for Marker Event");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setColour(120);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['marker_addlistener'] = function(block) {
  var value_marker = Blockly.JavaScript.valueToCode(block, 'Marker', Blockly.JavaScript.ORDER_ATOMIC);
  var dropdown_eventtype = block.getFieldValue('EventType');
  var statements_code = Blockly.JavaScript.statementToCode(block, 'code');
  // TODO: Assemble JavaScript into code variable.
  var code = value_marker+'.addListener("'+dropdown_eventtype+'",function(){'+statements_code+'})';
  return code;
};

Blockly.JavaScript['mapsly_geopoint'] = function(block) {
  var value_lat = Blockly.JavaScript.valueToCode(block, 'LAT', Blockly.JavaScript.ORDER_ATOMIC);
  var value_lng = Blockly.JavaScript.valueToCode(block, 'LNG', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
 var code = 'new Mapsly.GeoPoint('+value_lat+','+value_lng+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
Blockly.Blocks['create_marker'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Create Map Marker");
    this.appendValueInput("MARKERINFO")
        .setCheck("Mapsly.MarkerSettings")
        .appendField("Marker Information");
    this.setOutput(true, "google.maps.Marker");
    this.setColour(255);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['create_marker'] = function(block) {
  var value_markerinfo = Blockly.JavaScript.valueToCode(block, 'MARKERINFO', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new google.maps.Marker('+value_markerinfo+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
Blockly.Blocks['mapsly_mapstats'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Create Map Information");
    this.appendValueInput("lat")
        .setCheck("Number")
        .appendField("Latitude");
    this.appendValueInput("lng")
        .setCheck("Number")
        .appendField("Longitude");
    this.appendValueInput("zoom")
        .setCheck("Number")
        .appendField("Zoom");
    this.setOutput(true, "Mapsly.MapStats");
    this.setColour(120);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['mapsly_mapstats'] = function(block) {
  var value_lat = Blockly.JavaScript.valueToCode(block, 'lat', Blockly.JavaScript.ORDER_ATOMIC);
  var value_lng = Blockly.JavaScript.valueToCode(block, 'lng', Blockly.JavaScript.ORDER_ATOMIC);
  var value_zoom = Blockly.JavaScript.valueToCode(block, 'zoom', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new Mapsly.MapStats('+value_lat+','+value_lng+','+value_zoom+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
Blockly.Blocks['new_map'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Create Map");
    this.appendValueInput("document")
        .setCheck("HTMLDivElement")
        .appendField("Map Element");
    this.appendValueInput("mapstats")
        .setCheck("Mapsly.MapStats")
        .appendField("Map Information");
    this.setOutput(true, "google.maps.Map");
    this.setColour(290);
    this.itemCount_ = 0;
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  },
  mutationToDom: function(){
    var container = window.document.createElement("mutation");
  }
};
Blockly.JavaScript['new_map'] = function(block) {
  var value_document = Blockly.JavaScript.valueToCode(block, 'document', Blockly.JavaScript.ORDER_ATOMIC);
  var value_mapstats = Blockly.JavaScript.valueToCode(block, 'mapstats', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new google.maps.Map('+value_document +','+value_mapstats+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
Blockly.Blocks['mapsly_markerinfo'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Marker Information");
    this.appendValueInput("map")
        .setCheck("google.maps.Map")
        .appendField("Map");
    this.appendValueInput("position")
        .setCheck("Mapsly.GeoPoint")
        .appendField("Coordinates");
    this.appendValueInput("title")
        .setCheck("String")
        .appendField("Title");
    this.setOutput(true, "Mapsly.MarkerSettings");
    this.setColour(210);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['mapsly_markerinfo'] = function(block) {
  var value_map = Blockly.JavaScript.valueToCode(block, 'map', Blockly.JavaScript.ORDER_ATOMIC);
  var value_position = Blockly.JavaScript.valueToCode(block, 'position', Blockly.JavaScript.ORDER_ATOMIC);
  var value_title = Blockly.JavaScript.valueToCode(block, 'title', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new Mapsly.MarkerSettings('+value_map+','+value_position+','+value_title+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
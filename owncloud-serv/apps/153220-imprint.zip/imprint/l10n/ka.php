<?php $TRANSLATIONS = array(
"Admin" => "ადმინისტრატორი"
);

<?php
$TRANSLATIONS = array(
"Legal notice" => "法律声明",
"Nothing here yet" => "这里还什么都没有",
"The content of the legal notice has to be configured first" => "必须先配置法律通知等内容",
"That configuration is done in the administration section." => "那个配置会在管理部分完成。",
"That configuration has to be done by the system administration." => "那个配置必须在系统管理部分完成。",
"Imprint" => "版本说明",
"Placement" => "放置",
"Standalone app" => "独立的应用程序",
"Header left" => "页眉居左",
"Header right" => "页眉居右",
"Navigation top" => "导航置顶",
"Navigation bottom" => "导航置底",
"During login" => "在登录中",
"Content" => "内容",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "你可以使用html标记 (例如，使用 &lt;br&gt; 断行)和内嵌样式属性(例如，<a style=\"color:red;\">)"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

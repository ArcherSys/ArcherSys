<?php
$TRANSLATIONS = array(
"Legal notice" => "اخطار قانونی",
"Nothing here yet" => "اینجا هنوز چیزی نیست.",
"The content of the legal notice has to be configured first" => "محتوی اخطار قانونی ابتدا باید تنظیم شود.",
"That configuration is done in the administration section." => " پیکربندی در بخش مدیریت انجام شده است.",
"That configuration has to be done by the system administration." => "پیکر بندی باید توسط مدیریت سیستم انجام شود.",
"Imprint" => "مهر زدن",
"Placement" => "کاریابی",
"Standalone app" => "برنامه های رایج",
"Header left" => "سربرگ سمت چپ",
"Header right" => "سربرگ سمت راست",
"Navigation top" => "کنترل بالا",
"Navigation bottom" => "کنترل پایین",
"During login" => "در هنگام ورود به سیستم",
"Content" => "محتوا"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

<?php
$TRANSLATIONS = array(
"Legal notice" => "Lainopillinen huomautus",
"Nothing here yet" => "Täällä ei ole vielä mitään",
"The content of the legal notice has to be configured first" => "Lainopillinen huomautus on määriteltävä ensin",
"Placement" => "Sijoittelu",
"Content" => "Sisältö",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Voit käyttää html-merkintöjä (esim. <br> vaihtaa riviä) ja sisäisiä tyylimäärityksiä (esim. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

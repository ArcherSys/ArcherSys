<?php $TRANSLATIONS = array(
"Admin" => "පරිපාලක"
);

<?php
$TRANSLATIONS = array(
"Legal notice" => "Impressum",
"Nothing here yet" => "Hier gibt's noch nichts",
"The content of the legal notice has to be configured first" => "Der Inhalt des Impressums muss zuerst konfiguriert werden",
"That configuration is done in the administration section." => "Diese Konfiguration wird im Administrationsabschnitt vorgenommen.",
"That configuration has to be done by the system administration." => "Diese Konfiguration muss von einem Administrator vorgenommen werden.",
"Imprint" => "Impressum",
"Placement" => "Platzierung",
"Standalone app" => "Eigenständige Anwendung",
"Header left" => "Kopfzeile links",
"Header right" => "Kopfzeile rechts",
"Navigation top" => "Navigation oben",
"Navigation bottom" => "Navigation unten",
"During login" => "Während der Anmeldung",
"Content" => "Inhalt"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

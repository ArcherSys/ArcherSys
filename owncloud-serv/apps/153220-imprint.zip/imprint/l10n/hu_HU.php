<?php
$TRANSLATIONS = array(
"Legal notice" => "Jogi nyilatkozat",
"Nothing here yet" => "Még semmi nincs itt",
"The content of the legal notice has to be configured first" => "Elsőként a jogi nyilatkozat tartalmát kell meghatározni",
"That configuration is done in the administration section." => "Ez a konfiguráció az adminisztráció szekciónál állitható.",
"That configuration has to be done by the system administration." => "Ezt a konfigurációt a rendszer adminisztráció szekciónál kell beállítani.",
"Imprint" => "Impresszum",
"Placement" => "Elhelyezés",
"Standalone app" => "Különálló alkalmazás",
"Header left" => "Fejléc bal",
"Header right" => "Fejléc jobb",
"Navigation top" => "Navigáció fent",
"Navigation bottom" => "Navigáció lent",
"During login" => "Bejelentkezés közben",
"Content" => "Tartalom",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "HTML kódok (pl. <br> a sortörés jelzésére) és inline stílusok (pl.  <a style=\"color:red;\">) is használhatók."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

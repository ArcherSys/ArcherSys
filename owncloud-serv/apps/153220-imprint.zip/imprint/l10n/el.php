<?php
$TRANSLATIONS = array(
"Legal notice" => "Aνακοίνωση νομικού περιεχομένου",
"Nothing here yet" => " Δεν υπάρχει τίποτα εδώ μέχρι στιγμής",
"The content of the legal notice has to be configured first" => "Αρχικά πρέπει να διαμορφωθούν τα στοιχεία της ανακοίνωσης νομικού περιεχομένου",
"That configuration is done in the administration section." => "Η διαμόρφωση γίνεται στο τμήμα διαχείρισης.",
"That configuration has to be done by the system administration." => "Η διαμόρφωση πρέπει να γίνει από το διαχειριστή του συστήματος. ",
"Imprint" => "Αποτύπωμα",
"Placement" => "Τοποθέτηση",
"Standalone app" => "Αυτόνομη εφαρμογή",
"Header left" => "Αριστερή επικεφαλίδα",
"Header right" => "Δεξιά επικεφαλίδα",
"Navigation top" => "Πλοήγηση στο επάνω μέρος",
"Navigation bottom" => "Πλοήγηση στο κάτω μέρος",
"During login" => "Κατά τη σύνδεση",
"Content" => "Περιεχόμενο",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Μπορείτε να χρησιμοποιήσετε σήμανση html (π.χ. <br> για να αφήσετε μια κενή γραμμή) και ενωματωμένα χαρακτηριστικά στυλ (π.χ. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

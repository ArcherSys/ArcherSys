<?php
$TRANSLATIONS = array(
"Legal notice" => "Правна забелешка",
"Nothing here yet" => "Тука сеуште нема ништо",
"That configuration is done in the administration section." => "Ова нагодување е направено во секцијата за администрација.",
"Standalone app" => "Самостојна апликација",
"Header left" => "Заглавие лево",
"Header right" => "Заглавие десно",
"Navigation top" => "Навигацијата горе",
"Navigation bottom" => "Навигацијата долу",
"During login" => "Додека се најавувате",
"Content" => "Содржина"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";

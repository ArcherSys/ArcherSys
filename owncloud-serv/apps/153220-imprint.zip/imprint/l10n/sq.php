<?php
$TRANSLATIONS = array(
"Legal notice" => "Njoftim ligjor",
"Nothing here yet" => "Asgjë këtu ende",
"The content of the legal notice has to be configured first" => "Përmbajtja e njoftimit ligjor duhet të jetë konfiguruar e para",
"That configuration is done in the administration section." => "Ky konfigurim bëhet në seksionin e administrimit.",
"That configuration has to be done by the system administration." => "Kjo konfigurimit është bërë nga administrata e sistemit.",
"Imprint" => "Stampoj",
"Placement" => "Vendosje",
"Standalone app" => "App vetiake",
"Header left" => "Koka majtas",
"Header right" => "Koka djathtas",
"Navigation top" => "Udhëto lart",
"Navigation bottom" => "Udhëto poshtë",
"During login" => "Gjatë hyrjes",
"Content" => "Përmbajtje",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Ju mund të përdorni Markup html (p.sh. <br> për një ndarje) dhe atributet stilit në linjë (p.sh. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

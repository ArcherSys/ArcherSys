<?php
$TRANSLATIONS = array(
"Nothing here yet" => "بۇ جايدا تېخى ھېچنېمە يوق",
"Header left" => "سول بەت قېشى",
"Header right" => "ئوڭ بەت قېشى",
"Content" => "مەزمۇن"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

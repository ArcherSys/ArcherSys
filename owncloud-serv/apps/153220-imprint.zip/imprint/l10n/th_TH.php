<?php
$TRANSLATIONS = array(
"Content" => "เนื้อหา"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

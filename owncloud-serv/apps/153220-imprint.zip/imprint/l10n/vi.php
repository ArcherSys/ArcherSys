<?php
$TRANSLATIONS = array(
"Imprint" => "Đánh dấu",
"Content" => "Nội dung"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

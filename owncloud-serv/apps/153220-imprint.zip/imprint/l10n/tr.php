<?php
$TRANSLATIONS = array(
"Legal notice" => "Yasal uyarı",
"Nothing here yet" => "Henüz burada bir şey yok",
"The content of the legal notice has to be configured first" => "İlk olarak yasal uyarı içeriği yapılandırılmalıdır",
"That configuration is done in the administration section." => "Bu yapılandırma yönetim bölümünde yapılır.",
"That configuration has to be done by the system administration." => "Bu yapılandırma sistem yöneticisi tarafından yapılmalıdır.",
"Imprint" => "İzlenim",
"Placement" => "Yerleşim",
"Standalone app" => "Bağımsız uygulama",
"Header left" => "Sol başlık",
"Header right" => "Sağ başlık",
"Navigation top" => "Üst gezinme",
"Navigation bottom" => "Alt gezinme",
"During login" => "Giriş esnasında",
"Content" => "İçerik",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Html biçimlendirme (örneğin: <br> bir satır aralığı) ve satır içi biçem niteliklerini (örneğin: <a style=\"color:red;\">) kullanabilirsiniz."
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";

<?php
$TRANSLATIONS = array(
"Legal notice" => "Información legal",
"Nothing here yet" => "Todavía no hay nada aquí",
"The content of the legal notice has to be configured first" => "El contenido de la información legal ha de ser configurado primero",
"That configuration is done in the administration section." => "Esta configuración es realizada en la sección de administración.",
"That configuration has to be done by the system administration." => "Esta configuración debe hacerse por el administrador del sistema.",
"Imprint" => "Imprint",
"Placement" => "Ubicación",
"Standalone app" => "App autónoma",
"Header left" => "Encabezado izquierdo",
"Header right" => "Encabezado derecho",
"Navigation top" => "Navegación superior",
"Navigation bottom" => "Navegación inferior",
"During login" => "Durante el inicio de sesión",
"Content" => "Contenido",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Puede utilizar el formato HTML (por ejemplo <br> para un salto de línea) y los atributos de estilo en línea (por ejemplo <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

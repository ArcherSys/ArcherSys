<?php $TRANSLATIONS = array(
"Admin" => "به‌ڕێوه‌به‌ری سه‌ره‌كی"
);

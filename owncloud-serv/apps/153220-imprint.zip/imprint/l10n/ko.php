<?php
$TRANSLATIONS = array(
"Legal notice" => "법적 고지",
"Nothing here yet" => "아무것도 없습니다",
"The content of the legal notice has to be configured first" => "법적 고지의 내용을 먼저 설정해야 합니다",
"That configuration is done in the administration section." => "이 설정은 관리자 부분에서 완료되었습니다.",
"That configuration has to be done by the system administration." => "이 설정은 시스템 관리자에 의해 완료되었습니다.",
"Imprint" => "Imprint",
"Placement" => "배치",
"Standalone app" => "단독 앱",
"Header left" => "머릿글 왼쪽",
"Header right" => "머릿글 오른쪽",
"Navigation top" => "탐색 영역 위",
"Navigation bottom" => "탐색 영역 아래",
"During login" => "로그인 화면",
"Content" => "내용",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "HTML 마크업(예: 줄을 띄울 때 <br> 삽입) 및 인라인 스타일 속성(예: <a style=\"color:red;\">)을 사용할 수 있습니다."
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

<?php $TRANSLATIONS = array(
"Admin" => "প্রশাসন"
);

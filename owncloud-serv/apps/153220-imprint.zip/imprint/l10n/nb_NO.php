<?php
$TRANSLATIONS = array(
"Legal notice" => "Juridiske merknader",
"Nothing here yet" => "Ingenting her ennå",
"The content of the legal notice has to be configured first" => "Innholdet i de juridiske merknadene må konfigureres først",
"That configuration is done in the administration section." => "Den konfigureringen gjøres i administrasjonsseksjonen.",
"That configuration has to be done by the system administration." => "Den konfigureringen må gjøres av systemadministrasjonen.",
"Imprint" => "Avtrykk",
"Placement" => "Plassering",
"Standalone app" => "Frittstående app",
"Header left" => "Overskrift venstre",
"Header right" => "Overskrift høyre",
"Navigation top" => "Navigering topp",
"Navigation bottom" => "Navigering bunn",
"During login" => "Under innlogging",
"Content" => "Innhold",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Du kan bruke html markup (f.eks. <br> for et linjeskift) og inline stil-attributter (f.eks. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

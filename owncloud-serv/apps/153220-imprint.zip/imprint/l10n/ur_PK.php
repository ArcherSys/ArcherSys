<?php $TRANSLATIONS = array(
"Admin" => "ایڈمن"
);

<?php
$TRANSLATIONS = array(
"Legal notice" => "Leĝa sciigilo",
"Nothing here yet" => "Nenio ĉeestas ankoraŭ",
"The content of the legal notice has to be configured first" => "La enhavo de la leĝa sciigilo devas agordiĝi unue",
"That configuration is done in the administration section." => "Tiu agordo fariĝis en la administra sekcio.",
"That configuration has to be done by the system administration." => "Tiun agordon devas fari la sistemadministranto.",
"Placement" => "Pozicio",
"Standalone app" => "Memstara aplikaĵo",
"Header left" => "Maldekstro de kapo",
"Header right" => "Dekstro de kapo",
"Navigation top" => "Naviga supro",
"Navigation bottom" => "Naviga malsupro",
"During login" => "Dum ensaluto",
"Content" => "Enhavo"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

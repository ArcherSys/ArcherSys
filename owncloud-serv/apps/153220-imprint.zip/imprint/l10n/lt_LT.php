<?php
$TRANSLATIONS = array(
"Legal notice" => "Teisinis pranešimas",
"Nothing here yet" => "Kol kas čia nieko nėra",
"The content of the legal notice has to be configured first" => "Pirmiausia turi būti sukonfigūruotas teisinio pranešimo turinys",
"That configuration is done in the administration section." => "Šie nustatymai atliekami administracinėje panelėje.",
"That configuration has to be done by the system administration." => "Šie nustatymai turi būti atlikti sistemos administratoriaus.",
"Imprint" => "Imprint",
"Placement" => "Išdėstymas",
"Standalone app" => "Pavienė programa",
"Header left" => "Antraštė kairėje",
"Header right" => "Antraštė dešinėje",
"Navigation top" => "Meniu viršuje",
"Navigation bottom" => "Meniu mygtukas",
"During login" => "Prisijungimo metu",
"Content" => "Turinys",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Jūs galite naudoti html žymėjimą (pvz. <br> eilutės lūžiui) ir vidinius stiliau atributus (pvz. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);";

<?php $TRANSLATIONS = array(
"Admin" => "Adninistracija"
);

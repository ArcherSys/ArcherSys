<?php $TRANSLATIONS = array(
"Admin" => "Administrator"
);

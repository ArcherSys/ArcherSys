<?php
$TRANSLATIONS = array(
"Legal notice" => "Hysbysiad cyfreithiol",
"Nothing here yet" => "Does dim byd yma eto",
"The content of the legal notice has to be configured first" => "Rhaid cyflunio'r hysbysiad cyfreithiol yn gyntaf",
"That configuration is done in the administration section." => "Cyflunir hwnna yn yr adran weinyddol.",
"That configuration has to be done by the system administration." => "Rhaid i'r gweinyddwr system gyflunio hwnna.",
"Imprint" => "Imprint",
"Placement" => "Lleoliad",
"Standalone app" => "Ap arunig",
"Header left" => "Pennyn chwith",
"Header right" => "Pennyn dde",
"Navigation top" => "Llywio brig",
"Navigation bottom" => "Llywio gwaelod",
"Content" => "Cynnwys"
);
$PLURAL_FORMS = "nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;";

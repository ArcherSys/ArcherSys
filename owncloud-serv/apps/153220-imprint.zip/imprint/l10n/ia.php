<?php $TRANSLATIONS = array(
"Admin" => "Administration"
);

<?php
$TRANSLATIONS = array(
"Legal notice" => "Õigusalane teave",
"Nothing here yet" => "Siin pole veel midagi",
"The content of the legal notice has to be configured first" => "Õigusalase teabe sisu tuleb esmalt seadistada",
"That configuration is done in the administration section." => "Seda saab seadistada admini lehel.",
"That configuration has to be done by the system administration." => "Selle peab seadistama süsteemi administraator.",
"Imprint" => "Impressum",
"Placement" => "Asetus",
"Standalone app" => "Eraldi rakendus",
"Header left" => "Vasak päis",
"Header right" => "Parem päis",
"Navigation top" => "Navigatsioon üleval",
"Navigation bottom" => "Navigatsioon all",
"During login" => "Sisselogimise ajal",
"Content" => "Sisu",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Saad kasutada HTML märgendeid (nt. <br> reavahetuseks) ning sisestiili atribuute (nt. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

<?php
$TRANSLATIONS = array(
"Legal notice" => "Aviso legal",
"Nothing here yet" => "Aquí aínda non hai nada",
"The content of the legal notice has to be configured first" => "Primeiro ten que configurar o contido do aviso legal",
"That configuration is done in the administration section." => "Esta configuración faise na sección de administración.",
"That configuration has to be done by the system administration." => "Esa configuración ten de ser feita pola administración do sistema.",
"Imprint" => "Impresión",
"Placement" => "Emprazamento",
"Standalone app" => "Aplicativo independente",
"Header left" => "Cabeceira esquerda",
"Header right" => "Cabeceira dereita",
"Navigation top" => "Enriba na navegación",
"Navigation bottom" => "Embaixo na navegación",
"During login" => "Durante o acceso",
"Content" => "Contido",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Pode empregar o formato de marcado HTML (p.ex.  <br> para un salto de liña) e os atributos de estilo na liña (p.ex <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

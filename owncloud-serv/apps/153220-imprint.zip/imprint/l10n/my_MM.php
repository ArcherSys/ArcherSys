<?php $TRANSLATIONS = array(
"Admin" => "အက်ဒမင်"
);

<?php
$TRANSLATIONS = array(
"Legal notice" => "Juridisk informasjon",
"Nothing here yet" => "Ingenting her enno",
"The content of the legal notice has to be configured first" => "Du må skriva inn tekst i den juridiske informasjonen først",
"That configuration is done in the administration section." => "Den konfigurasjonen gjer du i administrasjonsdelen.",
"That configuration has to be done by the system administration." => "Den konfigurasjonen må gjerast av systemadministrasjonen.",
"Imprint" => "Impressum",
"Placement" => "Plassering",
"Standalone app" => "Frittståande applikasjon",
"Header left" => "Topptekst, venstre",
"Header right" => "Topptekst, høgre",
"Navigation top" => "Navigasjon, øvst",
"Navigation bottom" => "Navigasjon, nedst",
"During login" => "Ved innlogging",
"Content" => "Innhald",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Du kan bruka HTML-merking (t.d. <br> for linjeskift) og stilattributt (t.d. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

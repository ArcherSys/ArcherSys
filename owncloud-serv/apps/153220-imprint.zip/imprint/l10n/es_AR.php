<?php
$TRANSLATIONS = array(
"Legal notice" => "Información Legal",
"Nothing here yet" => "Todavía no hay nada aquí",
"The content of the legal notice has to be configured first" => "El contenido acerca de la información legal tiene que ser configurado primero",
"That configuration is done in the administration section." => "Eso se configura en la sección de administración.",
"That configuration has to be done by the system administration." => "Eso tiene que configurarse en administración de sistema.",
"Imprint" => "Imprint",
"Placement" => "Ubucación",
"Standalone app" => "Aplicación específica",
"Header left" => "Encabezado izquierdo",
"Header right" => "Encabezado derecho",
"Navigation top" => "Navegación extremo superior",
"Navigation bottom" => "Navegación extremo inferior",
"During login" => "Durante inicio de sesión",
"Content" => "Contenido",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Podés usar código html (p.ej. <br> para un salto de línea) y atributos de estilo (p.ej.  <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

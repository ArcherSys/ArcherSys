<?php
$TRANSLATIONS = array(
"Legal notice" => "Nota legal",
"Nothing here yet" => "Aquí encara no hi ha res",
"The content of the legal notice has to be configured first" => "Primer heu de configurar el contingut de la nota legal",
"That configuration is done in the administration section." => "Aquesta configuració es du a terme a la secció d'administració.",
"That configuration has to be done by the system administration." => "Aquesta configuració l'ha de realitzar l'administrador del sistema.",
"Imprint" => "Imprint",
"Placement" => "Ubicació",
"Standalone app" => "Aplicació autònoma",
"Header left" => "Encapçalament esquerra",
"Header right" => "Encapçalament dret",
"Navigation top" => "Navegació superior",
"Navigation bottom" => "Navegació inferior",
"During login" => "Durada de l'accés",
"Content" => "Contingut",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Podeu usar marques html  (per exemple <br> per un salt de línia) i atributs d'estil en línia (per exemple <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

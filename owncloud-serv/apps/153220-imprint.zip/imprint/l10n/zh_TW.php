<?php
$TRANSLATIONS = array(
"Legal notice" => "法律聲明",
"Nothing here yet" => "這裡沒有東西",
"The content of the legal notice has to be configured first" => "必須先設定法律聲明的內容",
"That configuration is done in the administration section." => "那項設定需在管理者界面完成",
"That configuration has to be done by the system administration." => "那項設定必須由系統管理者來完成。",
"Imprint" => "法律聲明",
"Placement" => "位置",
"Standalone app" => "獨立的應用程式",
"Header left" => "頁首內靠左",
"Header right" => "頁首內靠右",
"Navigation top" => "側欄頂端",
"Navigation bottom" => "側欄底端",
"During login" => "登入時",
"Content" => "內容",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "可以用 HTML 標記（像是 <br> 表示換行）和行內樣式屬性（如 <a style=\"color:red;\"> ）。"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

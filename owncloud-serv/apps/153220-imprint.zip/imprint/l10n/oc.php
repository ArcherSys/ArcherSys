<?php $TRANSLATIONS = array(
"Admin" => "Admin"
);

<?php
$TRANSLATIONS = array(
"Nothing here yet" => "នៅ​ទីនេះ​មិន​ទាន់​មាន​អ្វី​ទេ",
"Content" => "មាតិកា"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

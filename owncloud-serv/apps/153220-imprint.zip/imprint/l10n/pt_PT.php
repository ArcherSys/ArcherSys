<?php
$TRANSLATIONS = array(
"Legal notice" => "Notificação Legal",
"Nothing here yet" => "Vazio",
"The content of the legal notice has to be configured first" => "Primeiro, deve configurar o conteúdo da notificação legal atual",
"That configuration is done in the administration section." => "A configuração está concluída na secção de administração.",
"That configuration has to be done by the system administration." => "A configuração deve ser efetuada pela administração do sistema.",
"Imprint" => "Imprint",
"Placement" => "Colocação",
"Standalone app" => "Aplicação Autónoma",
"Header left" => "Cabeçalho Esquerdo",
"Header right" => "Cabeçalho Direito",
"Navigation top" => "Navegação Topo",
"Navigation bottom" => "Navegação Base",
"During login" => "Durante o início de sessão",
"Content" => "Conteúdo",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Pode usar marcação html (ex. <br> para uma quebra de linha) e atributos do estilo em linha (ex. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

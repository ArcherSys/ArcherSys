<?php $TRANSLATIONS = array(
"Admin" => "நிர்வாகம்"
);

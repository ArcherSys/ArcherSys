<?php
$TRANSLATIONS = array(
"Legal notice" => "Lagaleg atriði"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

<?php
$TRANSLATIONS = array(
"Legal notice" => "Lege oharra",
"Nothing here yet" => "Ezer hemen oraindik",
"The content of the legal notice has to be configured first" => "Lege oharraren edukia konfiguratu behar da lehenengo",
"That configuration is done in the administration section." => "Konfigurazioa hau kudeaketa atalean eginda dago.",
"That configuration has to be done by the system administration." => "Konfigurazioa sistema kudeatzaileak egin du.",
"Imprint" => "Imprint",
"Placement" => "Kokalekua",
"Standalone app" => "Bakarkako aplikazioa",
"Header left" => "Ezker goiburua",
"Header right" => "Eskuin goiburua",
"Navigation top" => "Nabigazio goikaldea",
"Navigation bottom" => "Nabigazio behekaldea",
"During login" => "Saioa hasi bitartean",
"Content" => "Edukia",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "html etiketak erabil ditzakezu (adb: <br> lerro berri baterako) eta etiketa barneko estilo atributuak (adb: <a style=\"color:red\")."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

<?php $TRANSLATIONS = array(
"Admin" => "管理"
);

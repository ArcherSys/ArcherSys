<?php
$TRANSLATIONS = array(
"Legal notice" => "إشعار قانوني",
"Nothing here yet" => "لا شيئ هنا إلى الآن.",
"The content of the legal notice has to be configured first" => "يجب أن يتم تهيئة محتوى الإشعار القانوني أولا.",
"That configuration is done in the administration section." => "هذا الإعداد قد تم في القسم الإداري.",
"That configuration has to be done by the system administration." => "هذا الإعداد يجب أن يتم بواسطة إدارة النظام.",
"Imprint" => "الدمغة.",
"Placement" => "وضع",
"Standalone app" => "تطبيق مستقل",
"Header left" => "رأس صفحة أيسر",
"Header right" => "رأس صفحة أيمن",
"Navigation top" => "تصفح أعلى",
"Navigation bottom" => "تصفح أسقل",
"During login" => "خلال تسجيل الدخول",
"Content" => "المحتوى",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "يمكنك استخدام رموز html (مثلا <br> لبداية سطر جديد) وخصية style (مثال <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;";

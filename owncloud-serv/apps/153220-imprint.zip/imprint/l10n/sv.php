<?php
$TRANSLATIONS = array(
"Legal notice" => "Rättsligt meddelande",
"Nothing here yet" => "Ingenting här än",
"The content of the legal notice has to be configured first" => "Innehållet i de rättsliga meddelandet måste först ha konfigurerats",
"That configuration is done in the administration section." => "Den konfigureringen görs från administratörssektionen",
"That configuration has to be done by the system administration." => "Den konfigureringen måste göras av systemadministratören.",
"Imprint" => "Imprint",
"Placement" => "Placering",
"Standalone app" => "Fristående app",
"Header left" => "Sidhuvud vänster",
"Header right" => "Sidhuvud höger",
"Navigation top" => "Navigering uppe",
"Navigation bottom" => "Navigering nere",
"During login" => "Under inloggning",
"Content" => "Innehåll",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Du kan använda HTML-kod (t.ex. <br> för en radbrytning) och stil-attribut (t.ex. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

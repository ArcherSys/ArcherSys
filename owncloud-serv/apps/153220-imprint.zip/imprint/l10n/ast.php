<?php
$TRANSLATIONS = array(
"Legal notice" => "Noticia llegal",
"Nothing here yet" => "Entá nun hai un res equí",
"The content of the legal notice has to be configured first" => "El conteníu de la noticia llegal tien de configurase primero",
"That configuration is done in the administration section." => "Esa configuración faise na seición d'alministración.",
"That configuration has to be done by the system administration." => "Esa configuración tien de facese pela alministración del sistema.",
"Imprint" => "Imprint",
"Placement" => "Allugamientu",
"Standalone app" => "App autónoma",
"Header left" => "Testera esquierda",
"Header right" => "Testera derecha",
"Navigation top" => "Navegación superior",
"Navigation bottom" => "Navegación inferior",
"During login" => "Nel aniciu de sesión",
"Content" => "Conteníu",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Pues usar el formatu HTML (por exemplu <br> pa un saltu de llinia) y los atributos d'estilu en llinia (por exemplu <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

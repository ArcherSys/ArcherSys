<?php
$TRANSLATIONS = array(
"Legal notice" => "Note legali",
"Nothing here yet" => "Qui ancora niente",
"The content of the legal notice has to be configured first" => "Il contenuto delle note legali deve essere precedentemente configurato ",
"That configuration is done in the administration section." => "La configurazione viene fatta nella sezione di amministrazione.",
"That configuration has to be done by the system administration." => "La configurazione deve essere fatta dall'amministrazione di sistema.",
"Imprint" => "Imprint",
"Placement" => "Posizionamento",
"Standalone app" => "Applicazione indipendente",
"Header left" => "Intestazione a sinistra",
"Header right" => "Intestazione a destra",
"Navigation top" => "Navigazione in alto",
"Navigation bottom" => "Navigazione in basso",
"During login" => "Durante l'accesso",
"Content" => "Contenuto",
"You can use html markup (e.g. <br> for a linebreak) and inline style attributes (e.g. <a style=\"color:red;\">)." => "Puoi utilizzare i contrassegni HTML (ad es. <br>  per un interruzione di riga) e gli attributi di stile in linea (ad es. <a style=\"color:red;\">)."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

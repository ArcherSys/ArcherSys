<?php
$TRANSLATIONS = array(
"Nothing here yet" => "Te neka vēl nav",
"Placement" => "Novietojums",
"Standalone app" => "Atsevišķa aplikācija ",
"During login" => "Ierakstīšanas brīdi",
"Content" => "Saturs"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);";

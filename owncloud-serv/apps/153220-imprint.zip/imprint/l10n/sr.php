<?php $TRANSLATIONS = array(
"Admin" => "Администратор"
);

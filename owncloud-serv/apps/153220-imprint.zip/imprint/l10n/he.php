<?php
$TRANSLATIONS = array(
"Legal notice" => "הערות משפטיות",
"Nothing here yet" => "אין כאן כלום עדיין",
"The content of the legal notice has to be configured first" => "יש להגדיר את תוכן ההערות המשפטיות תחילה",
"That configuration is done in the administration section." => "ניתן לשנות הגדרות אלו באגף הניהול.",
"That configuration has to be done by the system administration." => "הגדרות אלו ניתנות לשינוי על ידי מנהל המערכת.",
"Standalone app" => "יישום עצמאי",
"Header left" => "כותרת שמאלית",
"Header right" => "כותרת ימנית",
"Navigation top" => "ניווט עליון",
"Navigation bottom" => "ניווט תחתון",
"Content" => "תוכן"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";

<?php

namespace OCA\PDFLintViewer\Controller;

use \OCP\AppFramework\Controller;

class PageController extends Controller {
public function index() {
}
}
?>
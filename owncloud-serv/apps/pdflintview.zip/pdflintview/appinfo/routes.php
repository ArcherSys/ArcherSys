<?php
$this->create('pdflintview_index', '/')->action(
    function($params){
 header("Location: http://localhost/Producktiviti/PDFLint");    }
);

?>

Blockly.Blocks['document_gebid'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Get Element By ID");
    this.setOutput(true, "HTMLDivElement");
    this.setColour(65);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['document_gebid'] = function(block) {
  // TODO: Assemble JavaScript into code variable.
  var code = 'window.document.getElementById("map")';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NONE];
};
Blockly.Blocks['mapsly_mapstats'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Create Map Information");
    this.appendValueInput("lat")
        .setCheck("Number")
        .appendField("Latitude");
    this.appendValueInput("lng")
        .setCheck("Number")
        .appendField("Longitude");
    this.appendValueInput("zoom")
        .setCheck("Number")
        .appendField("Zoom");
    this.setOutput(true, "Mapsly.MapStats");
    this.setColour(120);
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['mapsly_mapstats'] = function(block) {
  var value_lat = Blockly.JavaScript.valueToCode(block, 'lat', Blockly.JavaScript.ORDER_ATOMIC);
  var value_lng = Blockly.JavaScript.valueToCode(block, 'lng', Blockly.JavaScript.ORDER_ATOMIC);
  var value_zoom = Blockly.JavaScript.valueToCode(block, 'zoom', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new Mapsly.MapStats('+value_lat+','+value_lng+','+value_zoom+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
Blockly.Blocks['new_map'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Create Map");
    this.appendValueInput("document")
        .setCheck("HTMLDivElement")
        .appendField("Map Element");
    this.appendValueInput("mapstats")
        .setCheck("Mapsly.MapStats")
        .appendField("Map Information");
    this.setOutput(true, "google.maps.Map");
    this.setColour(290);
    this.itemCount_ = 0;
    this.setTooltip('');
    this.setHelpUrl('http://www.example.com/');
  }
};
Blockly.JavaScript['new_map'] = function(block) {
  var value_document = Blockly.JavaScript.valueToCode(block, 'document', Blockly.JavaScript.ORDER_ATOMIC);
  var value_mapstats = Blockly.JavaScript.valueToCode(block, 'mapstats', Blockly.JavaScript.ORDER_ATOMIC);
  // TODO: Assemble JavaScript into code variable.
  var code = 'new google.maps.Map('+value_document +','+value_mapstats+')';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.JavaScript.ORDER_NEW];
};
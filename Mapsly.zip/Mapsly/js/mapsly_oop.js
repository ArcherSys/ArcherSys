
var Mapsly = {};
Mapsly.MapStats = function(lat,lng,zoom){
this.center = {
lat: lat, lng: lng
};
this.zoom = zoom;
};